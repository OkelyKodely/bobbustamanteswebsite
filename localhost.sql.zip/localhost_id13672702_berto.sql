-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 22, 2020 at 07:02 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id13672702_berto`
--
CREATE DATABASE IF NOT EXISTS `id13672702_berto` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `id13672702_berto`;

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `username` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`username`, `password`) VALUES
('berto', 'berto123');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `inputdate` date DEFAULT NULL,
  `folder` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `content`, `inputdate`, `folder`) VALUES
(1, 'Welcome to The Blog.  I\'m bored', '2020-05-13', '1'),
(2, 'The rap star common is the ball~', '2020-05-13', '2'),
(3, 'Address\r\n<br><br>\r\n401 W. Redondo Beach Blvd., Gardena, CA 90248', '2020-05-15', '5'),
(4, 'Are the non-elect used by the power of the Holy Spirit (God the Third Person) for common purposes alone?', '2020-05-15', '2'),
(5, 'your login username/password is berto/berto123.  Please change your password in phpmyadmin, Berto.  Thanks!~', '2020-05-17', '10'),
(6, 'God The Son\r\n<br>\r\n<br>\r\nGod always existed from all eternity and His Son was always with him.  He was the joy of God’s heart and they shined together like the radiance of the sun which God saw fit to create which would illumine the earth.  God the Son shines bright today and he makes all things new.  He is the very image of the uncreated God and the very essence of his being.  The Son outshines any angel in the heavens who give constant glory to God the Father and God the Holy Spirit.  The Lord is God the Son.  He is the triune person who from ages immemorial is the wonder of the being of the Trinity.  The very heart of God is in the Son who is magnificent and wonderous works are in the plan of God the Son who is in subordination to accomplish all that the Father plans and has in store for time and space.  God the Son broke into time and became a human being and was born in the fullness of time and he carries with him the very image of God the mysterious.  God forever is faithful to himself and knows all things that are true and everlasting, as well as the things that are not true and temporary.  He makes both honor and dishonor and makes his creation long for the truth.  But the elect yearn even more than the rest of creation who are not elect they bask in the truth and their minds are shaped in honor.  They are the apple of God’s sovereign eye, and he is their shepherd and their master.  Not so for the rest of creation created for common temporary purpose to better serve the elect.  The elect and God the Son together live in harmony and the elect always think that God is God the Son too.  Too.  Too.  Too.  Too.  Too.  Too.', '2020-05-17', '2'),
(7, 'God The Son<br>\r\n<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/t5zE2EouaW4\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', '2020-05-17', '9'),
(8, 'Koinonia\r\n<br><br>\r\n<iframe width=\"789\" height=\"444\" src=\"https://www.youtube.com/embed/D0un9iFm2-w\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', '2020-05-17', '9'),
(9, 'Bob’s Song (Fourth of July)\r\n<br><br>\r\nBorn on the fourth of July,\r\nMy head, hair, and snapback.\r\nBorn on the fourth of Remember,\r\nThe silliness of them all, just relax\r\n<br><br>\r\nWhen Laziness is a virtue,\r\nFilling my thoughts with you.\r\nTrust your words of kindness,\r\nNothing left but to “do”\r\n<br><br>\r\nThe evening time has arrived,\r\nStovetop cooking flames aside.\r\nWonder what kind of stars there will be,\r\nChanting all these melodie-es.\r\n<br><br>\r\n[Chorus]\r\n<br>\r\nBorn on the fourth of July,\r\nBorn on the fourth of them all,\r\nBorn to rock, roll, sing every night\r\n<br><br>\r\n[Outro]\r\n<br>\r\nBorn on the fourth of July,\r\nBorn on the fourth of them all,\r\nBorn to rock, roll, sing every night\r\nBorn on the fourth of July,\r\nBorn on the fourth of them all,\r\nBorn to rock, roll, sing every night\r\n', '2020-05-17', '14'),
(10, '<pre>\r\nBob’s Song (Fourth of July)\r\n\r\nDadd5          G/Badd9\r\nBorn on the fourth of July,\r\nGadd9                         Bm\r\nMy head, hair, and snapback.\r\nDadd5          G/Badd9\r\nBorn on the fourth of Remember,\r\nGadd9                         Bm\r\nThe silliness of them all, just relax\r\n\r\nDadd5          G/Badd9\r\nWhen Laziness is a virtue,\r\nGadd9                         Bm\r\nFilling my thoughts with you.\r\nDadd5          G/Badd9\r\nTrust your words of kindness,\r\nGadd9                         Bm\r\nNothing left but to “do”\r\n\r\nDadd5          G/Badd9\r\nThe evening time has arrived,\r\nGadd9                         Bm\r\nStovetop cooking flames aside.\r\nDadd5          G/Badd9\r\nWonder what kind of stars there will be,\r\nGadd9                         Bm\r\nChanting all these melodie-es.\r\n\r\n[Chorus]\r\n\r\nF/C                 C               G   GSUSadd6   G      GSUSadd6   G\r\nBorn on the fourth of July,\r\nF/C                 C               G   GSUSadd6   G      GSUSadd6   G\r\nBorn on the fourth of them all,\r\nF/C                 C               G   GSUSadd6   G      GSUSadd6   G\r\nBorn to rock, roll, sing every night\r\n\r\n[Outro]\r\n\r\nF/C                 C               G   GSUSadd6   G      GSUSadd6   G\r\nBorn on the fourth of July,\r\nF/C                 C               G   GSUSadd6   G      GSUSadd6   G\r\nBorn on the fourth of them all,\r\nF/C                 C               G   GSUSadd6   G      GSUSadd6   G\r\nBorn to rock, roll, sing every night\r\nF/C                 C               G   GSUSadd6   G      GSUSadd6   G\r\nBorn on the fourth of July,\r\nF/C                 C               G   GSUSadd6   G      GSUSadd6   G\r\nBorn on the fourth of them all,\r\nF/C                 C               G   GSUSadd6   G      GSUSadd6   G\r\nBorn to rock, roll, sing every night\r\n\r\n</pre>', '2020-05-17', '14'),
(11, 'VBS Songs Mix\r\n<br>\r\n<iframe width=\"789\" height=\"444\" src=\"https://www.youtube.com/embed/vt6TsIAHIgs?list=PLpwjExiLZ46arCSbiGlEcaylkSIqqIy5U\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', '2020-05-17', '6'),
(12, 'Hello, world!', '2020-05-18', '2');

-- --------------------------------------------------------

--
-- Table structure for table `folder`
--

CREATE TABLE `folder` (
  `id` int(11) DEFAULT NULL,
  `folder` text COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `folder`
--

INSERT INTO `folder` (`id`, `folder`) VALUES
(1, 'special'),
(2, 'common'),
(3, 'VISITING'),
(4, 'ABOUT MEDIA'),
(5, 'DIRECTIONS'),
(6, 'VBS'),
(7, 'HISTORY'),
(8, 'STAFF'),
(9, 'VIDEO UPLOADS'),
(10, 'Q & A'),
(13, 'Incense'),
(14, 'Songs');
